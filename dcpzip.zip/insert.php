<?php

/*Form Entries*/
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$phone_number = $_POST['phone_number'];

/*DB Cred*/
if (!empty($username) || !empty($password))  {
    $host = "localhost:3306";
    $dbUser = "sgchs_cikerd";
    $dbPass ="hornets";
    $dbname = "sgchs_cikerd";
    
    /*Connect*/
        $mysqli = new mysqli('localhost:3306', 'sgchs_cikerd', 'hornets','sgchs_cikerd');

        /*Fail to Entry Return*/
    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_error().')'. mysqli_connect_error());
    }   else {

        /*Form Limits*/
            $SELECT = "SELECT username From register Where username = ? Limit 1";
            $INSERT = "INSERT Into register (username, password, email, phone_number) values(?, ?, ?, ?)"; 

                 $stmt = $mysqli->prepare($SELECT);
                 $stmt->bind_param("s", $username);
                 $stmt->execute();
                 $stmt->bind_result($username);
                 $stmt->store_result();
                 $rnum = $stmt->num_rows;

                    if($rnum==0){
                    $stmt->close();

            $stmt = $mysqli->prepare($INSERT);
            $stmt->bind_param("sssi",$username, $password, $email, $phone_number);

            /*Entry Notification*/
            $stmt->execute();
            echo "New record inserted sucessfully";
        } else{
            echo "This Username is already registered";
        }
        /*Disconect*/
        $stmt->close();
        $mysqli->close();
    }

}else {
    echo "All fields are required";
    die();
}
?>

<html>
    <head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta content="text/html">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/css/bootstrap.min.css" integrity="sha384-AysaV+vQoT3kOAXZkl02PThvDr8HYKPZhNT5h/CXfBThSRXQ6jW5DO2ekP5ViFdi" crossorigin="anonymous">
  <link rel="stylesheet" href="style3.css" type="text/css">
    </head>
        <body>
            <center><h1>Discounted Computer Parts</h1></center>
                <div class="hbot">
                     <div class="container">
                         <nav class="navbar navbar-full navbar-dark bg-inverse">
                              <button class="navbar-toggler light float-xs-right hidden-sm-up" type="button" data-toggle="collapse" data-target="#nvbar"></button>
                              <div id="nvbar" class="collapse navbar-toggleable-xs">
                                      <ul class="nav navbar-nav float-sm-right ">
                                      <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
                                        <li class="nav-item"><a class="nav-link" href="about.html">About</a></li>
                                       <li class="nav-item"><a class="nav-link" href="index.html">Products</a></li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
      <br>
      <div class="container">
          <div class="col-md-12 col-lg-12">
         <center> <div class="btn">
     <a href="index2.html"><button type="button" class="btn btn-info">Return</button></a> </center>
</div>
</div>
</body>
</html>