<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta content="text/html">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/css/bootstrap.min.css" integrity="sha384-AysaV+vQoT3kOAXZkl02PThvDr8HYKPZhNT5h/CXfBThSRXQ6jW5DO2ekP5ViFdi" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="style2.css" media="screen"/>
  </head>

<body>
<header class="header">
    <div class=container>
        <h1>Discounted Computer Parts</h1>
        <div id="frm">
            <form method="POST"action="insert.php">
                <div class="wrapper">
                    <div class="contact-form">
                      <div class="input-fields">
                        <input type="text"        name="username"   class="input" placeholder="Username" id="user" required>
                        <input type="password"    name="password"   class="input" placeholder="Password" id="pass"required></div>
                        <input class="btn"  name="submit"    type="submit"     id="btn"      value="LOGIN" >
                    </div>
                  </div>	
            </form>
      </div>


</body>
</html>
