<?php
$username = $_POST['username'];
$password = $_POST['password'];

if (!empty($username) || !empty($password) || !empty($email)) {
    $host = "datadev.devcatalyst.com";
    $dbUser = "root";
    $dbPassword ="";
    $dbname = "sgchs_cikerd";
    
    $mysqli = new mysqli('localhost:3306', 'sgchs_cikerd', "hornets','dbname');

    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_error().')'. mysqli_connect_error());
    }   else {
        $SELECT = "SELECT email From register Where email = ? Limit 1";
        $INSERT = "INSERT Into register (username, password) values(?, ?, ?)";

        $stmt = $conn->prepare($SELECT);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($email);
        $stmt->store_result();
        $rnum = $stmt->num_rows;

        if($rnum==0){
            $stmt->close();

            $stmt = $conn->prepare($INSERT);
            $stmt->bind_param("ss",$username, $passowrd);
            $stmt->execute();
            echo "New record inserted sucessfully";
        } else{
            echo "This Username is already registered";
        }
        $stmt->close();
        $conn->close();
    }

}else {
    echo "All fields are required";
    die();
}
?>